<div id="footer">
&copy; <a href="httpp://www.ceilwoo.com/blog">Udolpho</a> Design by <a href="http://www.ceilwoo.com">Ceilwoo</a>  Powered by <a href="http://wordpress.org/">WordPress</a>.
</div>
</div>
</body>
</html>