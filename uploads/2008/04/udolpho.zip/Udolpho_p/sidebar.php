<div class="sidebar">
	<ul>
	<?php 	/* Widgetized sidebar, if you have the plugin installed. */
					if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar() ) : ?>
   	<li id="custom">
       	<ul>
           <li><a href="<?php echo get_option('home'); ?>" class="home">Home</a></li>
           <?php wp_list_pages('title_li=&depth=1'); ?>
           <li><a href="<?php bloginfo('rss2_url'); ?>" title="The latest comments to all posts in RSS" class="rss">RSS</a></li>
        </ul>
     </li>
     <li id="search">
		<?php include (TEMPLATEPATH . '/searchform.php'); ?>
     </li>
     <li id="categories">
       	<h3>Categories</h3>
        <ul>
        <?php wp_list_categories('title_li=&sort_column=name&optioncount=1&hierarchical=0'); ?>
        <!--?php wp_list_cats('sort_column=name&optioncount=1&hierarchical=0'); ?-->
        </ul>
      </li>
       <li id="r_posts">
  		  <h3>Recent Posts</h3>
          <?php query_posts('showposts=5'); ?>
        <ul>
        <?php while (have_posts()) : the_post(); ?>
        <li>
        <a href="<?php the_permalink() ?>" rel="bookmark" title="<?php _e('Permanent link to'); ?> <?php the_title(); ?>"><?php the_title(); ?></a>
        <span>&nbsp;-&nbsp;<?php the_time('M j,Y') ?></span>
        </li>
        <?php endwhile;?>
        </ul>
 		 </li>
          <?php wp_list_bookmarks('title_before=<h3>&title_after=</h3>&show_images=0') ?>
                
          <!--li id="archives">
          <h3>Archives</h3>
			<ul>
			<?php wp_get_archives('type=monthly'); ?>
			</ul>
			</li-->
        <li id="rss">
        <a href="<?php bloginfo('rss2_url'); ?>" title="RSS">RSS</a>
        </li>
        <?php endif; ?>
	</ul>
</div>