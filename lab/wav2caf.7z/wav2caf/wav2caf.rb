require "fileutils"

def caf2wav(filename)
	cmd = "afconvert -f caff -d LEI16@44100 -c 1 #{filename}.wav #{filename}.caf"
	system(cmd)
	puts "#{filename}.caf.......done........"
end

Dir.glob("*.wav"){ |filename|
  base = File.basename(filename, ".wav")
  caf2wav(base)
}
