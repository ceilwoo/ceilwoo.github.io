require "fileutils"

def caf2wav(filename)
	cmd = "afconvert -f WAVE -d LEI16@44100 #{filename}.caf #{filename}.wav"
	system(cmd)
	puts "#{filename}.caf.......done........"
end

Dir.glob("*.caf"){ |filename|
  base = File.basename(filename, ".caf")
  caf2wav(base)
}
